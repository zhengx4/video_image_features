python image_features/hog.py

python image_features/color_histogram.py

python image_features/lbp.py

python image_features/orb.py

python image_features/inceptionV3.py
