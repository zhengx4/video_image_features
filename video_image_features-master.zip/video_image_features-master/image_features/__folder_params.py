home = '/media/ricardo/wk/2018Memorability/video_image_features/'
data_folder = home + "../data/"
